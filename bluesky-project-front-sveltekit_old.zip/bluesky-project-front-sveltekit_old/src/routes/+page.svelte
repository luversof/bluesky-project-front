<script>
	// import { userInfo } from './userInfo.js';
</script>

최상위 index
