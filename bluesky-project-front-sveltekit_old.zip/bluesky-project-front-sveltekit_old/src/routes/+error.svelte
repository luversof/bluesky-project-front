<script>
	import Button from '$lib/components/Button.svelte';
</script>

<div class="min-h-screen flex">
	<div class="flex flex-col items-center justify-center w-full text-center">
		<div class="text-8xl font-black text-gray-800 p-10">404</div>

		<p class="text-3xl font-light leading-normal text-gray-600">Not Found</p>

		<Button href="/">Go Home</Button>
	</div>
</div>
