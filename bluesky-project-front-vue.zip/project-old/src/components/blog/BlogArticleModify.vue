<template>
  <div></div>
</template>
<script>
import blogMixin from '@/components/blog/blog.js'
export default {
  name: 'BlogArticleModify',
  mixins: [blogMixin],
  data () {
    return {
    }
  }
}
</script>
